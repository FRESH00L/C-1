﻿using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace ZadanieDomoweC_
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void btnOblicz_Click(object sender, RoutedEventArgs e)
        {
            double a, b, c;

            a = Convert.ToDouble(tbA.Text);
            b = Convert.ToDouble(tbB.Text);
            c = Convert.ToDouble(tbC.Text);

            if (a <= 0 || b < 0 || c < 0)
            {
                MessageBox.Show("Błędne dane", "Błąd", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            double delta = b * b - 4 * a * c;
            if (delta < 0)
            {
                lblWynik.Content = "Brak rozwiązań";
            }
            else if (delta == 0)
            {
                double x = -b / (2 * a);
                lblWynik.Content = $"Jedno rozwiązanie: x = {x:F2}";
            }
            else
            {
                double x1 = -b - Math.Sqrt(delta) / (2 * a);
                double x2 = -b + Math.Sqrt(delta) / (2 * a);

                lblWynik.Content = $"Dwa rozwiązania: x1 = {x1:F2} i x2 = {x2:F2}";
            }
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            int rowMax = 5;
            double rectWidth = 40;
            double rectHeight = 20;
            double startX = 10;
            double startY = cv.ActualHeight - 10;
            for (int row = 0; row < rowMax; row++)
            {
                for (int col = 0; col <= row; col++)
                { var myRectangle = new Rectangle();
                    myRectangle.Width = rectWidth;
                    myRectangle.Height = rectHeight;
                    myRectangle.Fill = Brushes.Beige;
                    Canvas.SetLeft(myRectangle, startX +col*rectWidth);
                    Canvas.SetTop(myRectangle, startY -row * rectHeight);
                    cv.Children.Add(myRectangle);
                }
            }
        }
    }
}