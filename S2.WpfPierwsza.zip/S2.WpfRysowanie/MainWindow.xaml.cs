﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace S2.WpfRysowanie
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        void RysujLinie(double x1, double y1, double x2, double y2, int thick = 1, SolidColorBrush color = null )
        {
            var myLine = new Line();
            //var myLine2 = new Line();
            myLine.StrokeThickness = thick;
            //myLine2.StrokeThickness = thick;


            if (color == null)
            {
                myLine.Stroke = System.Windows.Media.Brushes.Black;
                //myLine2.Stroke = System.Windows.Media.Brushes.Black;
            }
            else { myLine.Stroke= color;}

            myLine.X1 = x1;
            myLine.Y1 = y1;
            myLine.X2 = x2;
            myLine.Y2 = y2;

            //myLine2.X1 = 150;
            //myLine2.Y1 = 150;
            //myLine2.X2 = 150;
            //myLine2.Y2 = 300;

            cvRysunek.Children.Add(myLine);
            //cvRysunek.Children.Add(myLine2);


        }

        void RysujKrzyz(double x1, double y1, double lenght, int thick)
        {
            cvRysunek.Children.Clear();
            RysujLinie(x1, y1, x1+lenght, y1, thick, System.Windows.Media.Brushes.Red);
            RysujLinie(x1, y1, x1-lenght, y1, thick, System.Windows.Media.Brushes.Red);
            RysujLinie(x1, y1, x1, y1 - lenght, thick, System.Windows.Media.Brushes.Red);
            RysujLinie(x1, y1, x1, y1 + lenght, thick, System.Windows.Media.Brushes.Red);

            RysujLinie(x1 - 30, y1 - lenght, x1 + 30, y1 - lenght, thick, System.Windows.Media.Brushes.Red);
            RysujLinie(x1 - 30, y1 + lenght, x1 + 30, y1 + lenght, thick, System.Windows.Media.Brushes.Red);
            RysujLinie(x1 - lenght, y1 - 30, x1 - lenght, y1 + 30, thick, System.Windows.Media.Brushes.Red);
            RysujLinie(x1 + lenght, y1 - 30, x1 + lenght, y1 + 30, thick, System.Windows.Media.Brushes.Red);

            for(int i = 0; i < 4; i++)
            {
                RysujLinie(x1 + lenght/2, y1 - lenght / 2 - 10, x1 + lenght / 2, y1 - lenght / 2 + 10, 5, System.Windows.Media.Brushes.Red);
                RysujLinie(x1 + lenght/2 - 10, y1 - lenght / 2, x1 + lenght / 2 + 10, y1 - lenght / 2, 5, System.Windows.Media.Brushes.Red);
            }

        }

        void RysujElipse(double x1,double y1, double height,  double width, SolidColorBrush color = null) 
        {
            var elips = new Ellipse();
            elips.Stroke = System.Windows.Media.Brushes.DarkGreen;
            if (color != null)
            {
                elips.Fill = color;
            }
            
            elips.StrokeThickness = 3;
            elips.Width = width;
            elips.Height = height;
            cvRysunek.Children.Add(elips);
            Canvas.SetLeft(elips, x1);
            Canvas.SetTop(elips, y1);
            
        }

        void RysujDrzewo(double rootX1, double rootY1, double treeHeight, double leafWidth)
        {
            
            RysujLinie(rootX1, rootY1, rootX1,rootY1-treeHeight,10,System.Windows.Media.Brushes.Brown );
            RysujElipse(rootX1-leafWidth,rootY1-treeHeight-leafWidth*2, leafWidth * 2, leafWidth * 2, System.Windows.Media.Brushes.Green);
        }

        void RysujSzpalerDrzew(double firstX1, double firstY1, double distance, int number)
        {
            double treeHeight = 100;
            double leafWidth = 35;
            double dist = 0;
            for(int i = 0; i < number; i++) 
            { 
                RysujDrzewo(firstX1+dist, firstY1,treeHeight,leafWidth);
                dist += distance; 
            }
        }

        void RysujLosowySzpaler(double y,int minX, int maxX, int heightMin, int heightMax, int leafMin, int leafMax)
        {
            cvRysunek.Children.Clear();
            var rand = new Random();
            
            double oldX = 0, newX=0,height = 0, leafWidth = 0;
            for( int i = 0; i< 7;i++)
            {
                newX = rand.NextDouble() * (maxX - minX) + minX;
                //if(newX > oldX + leafMin)
                { 
                    height = rand.NextDouble() * (heightMax - heightMin) + heightMin;
                    leafWidth = rand.NextDouble() * (leafMax - leafMin) + leafMin;
                    RysujDrzewo(newX,y,height,leafWidth);
                    oldX = newX;
                }
                
            }
        }
        private void btnRysuj_Click(object sender, RoutedEventArgs e)
        {
            double X1, Y1, X2, Y2;
            int thick;
            X1 = Convert.ToDouble(tbX1.Text);
            X2 = Convert.ToDouble(tbX2.Text);
            Y1 = Convert.ToDouble(tbY1.Text);
            Y2 = Convert.ToDouble(tbY2.Text);
            thick = Convert.ToInt32(tbThick.Text);
            RysujLinie(X1,Y1,X2,Y2,thick);
            
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            cvRysunek.Children.Clear();
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            RysujKrzyz(150,150,70,10);
        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            double X1, Y1;
            X1 = Convert.ToDouble(tbX1.Text);
            Y1 = Convert.ToDouble(tbY1.Text);
            
            RysujElipse(X1,Y1, 200, 300);
        }

        private void Button_Click_3(object sender, RoutedEventArgs e)
        {
            double X1, Y1, r = 50;
            X1 = Convert.ToDouble(tbX1.Text);
            Y1 = Convert.ToDouble(tbY1.Text);
            
            RysujElipse(X1-r/2, Y1-r/2, r, r, System.Windows.Media.Brushes.Beige);
           
        }

        private void btnRysujDrzewo_Click(object sender, RoutedEventArgs e)
        {
            RysujDrzewo(150,150,50,30);
        }

        private void btnSzpalerDrzew_Click(object sender, RoutedEventArgs e)
        {
            RysujSzpalerDrzew(0,200, 50,7);
        }

        private void btnLosowySzpaler_Click(object sender, RoutedEventArgs e)
        {
            RysujLosowySzpaler(250, 50, 270, 40, 55, 30, 60);
        }
    }
}
