﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace S2.WpfRysowanie
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        void RysujLinie(double x1, double y1, double x2, double y2, int thick = 1, SolidColorBrush color = null )
        {
            var myLine = new Line();
            myLine.StrokeThickness = thick;

            if (color == null)
            {
                myLine.Stroke = System.Windows.Media.Brushes.Black;
            }

            myLine.X1 = x1;
            myLine.X2 = x2;
            myLine.Y1 = y1;
            myLine.Y1 = y2;

            cvRysunek.Children.Add(myLine);
        }

        void RysujKrzyz(double x1, double y1, int lenght, int thick)
        {

        }

        private void btnRysuj_Click(object sender, RoutedEventArgs e)
        {
            double X1, Y1, X2, Y2;
            int thick;
            X1 = Convert.ToDouble(tbX1.Text);
            X2 = Convert.ToDouble(tbX2.Text);
            Y1 = Convert.ToDouble(tbY1.Text);
            Y2 = Convert.ToDouble(tbY2.Text);
            thick = Convert.ToInt32(tbThick.Text);
            RysujLinie(X1,Y1,X2,Y2,thick);
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            cvRysunek.Children.Clear();
        }
    }
}
