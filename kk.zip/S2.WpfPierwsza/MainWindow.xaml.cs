﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace S2.WpfPierwsza
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void btnWitaj_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Hello world");
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                double r, h, V = 0, P = 0;
                r = Convert.ToDouble(txtPromien.Text);
                h = Convert.ToDouble(txtWysokosc.Text);
                if (r <= 0 || h <= 0)
                {
                    MessageBox.Show("Złe parametry");
                    return;
                }

                if (chkLiczenieObjetosci.IsChecked == true)
                {

                    switch (cmbWybierz.SelectedIndex)
                    {
                        case 0:
                            V = Math.PI * Math.Pow(r, 2) * h;
                            break;
                        case 1:
                            V = 1D / 3D * Math.PI * Math.Pow(r, 2) * h;
                            break;
                        case 2:
                            V = 3D / 4D * Math.PI * Math.Pow(r, 3);
                            break;

                    }

                    tbkWynik.Text = $"Objętość  {cmbWybierz.SelectionBoxItem} wynosi {V:F2} m^3";
                   
                    tbkWynik.Text = V.ToString();
                    tbkWynik.Text = $"Objętość walca wynosi {V:F2} m^3";
                }

                if (chkPole.IsChecked == true)
                {
                    switch (cmbWybierz.SelectedIndex)
                    {
                        case 0:
                            P = 2*Math.PI * h + 2*Math.PI * r*r;
                            break;
                        case 1:
                            P = 1D / 3D * Math.PI * Math.Pow(r, 2);
                            break;
                        case 2:
                            P = Math.PI * r * r;
                            break;

                    }
                    tbkWynik.Text = $"Pole  {cmbWybierz.SelectionBoxItem} wynosi {V:F2} m^3";
                }
            }
            catch
            {
                MessageBox.Show("Zły format");
            }


            
            
        }

        private void cmbWybierz_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (cmbWybierz.SelectedIndex == 2) 
            {
                txtWysokosc.Visibility = Visibility.Hidden;
            }
            else
            {
                txtWysokosc.Visibility = Visibility.Visible;
            }
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            if(MessageBox.Show("Czy napewno?", "Pytanie", MessageBoxButton.YesNo)==MessageBoxResult.Yes);
            this.Close();
            
        }
    }
}
